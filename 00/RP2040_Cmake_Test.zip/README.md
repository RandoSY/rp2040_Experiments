# RP2040_Cmake_Test

Minimal RP2040 + FreeRTOS + SEGGER Ozone Debug Template.

- Uses CMake + Pico SDK
- Supports FreeRTOS task scheduling
- Ready for J-Link and Ozone RTOS Plugin
